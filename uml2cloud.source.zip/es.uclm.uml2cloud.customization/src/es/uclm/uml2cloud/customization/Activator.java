package es.uclm.uml2cloud.customization;

import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "es.uclm.uml2cloud.customization"; //$NON-NLS-1$

}
