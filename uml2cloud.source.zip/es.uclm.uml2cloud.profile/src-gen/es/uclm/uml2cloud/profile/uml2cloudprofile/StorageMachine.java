/**
 */
package es.uclm.uml2cloud.profile.uml2cloudprofile;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Storage Machine</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see es.uclm.uml2cloud.profile.uml2cloudprofile.UML2CloudProfilePackage#getStorageMachine()
 * @model
 * @generated
 */
public interface StorageMachine extends Machine {
} // StorageMachine
